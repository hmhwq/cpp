from tools import *

debug = False # 当 debug 变量为真时，程序会输出一些内部信息，方便调试

# 请补全以下代码的 TODO 部分
# 注意，你无需了解函数调用的细节

def is_game_over():
    '''
    每次鼠标单击事件后会调用此函数，判断是否触雷，返回 True 或 False
    is_mine(x,y) : 当(x,y)坐标存在地雷时，返回 True，否则返回 False
    mouse_x : 鼠标单击位置的 x 坐标，初始化代码已给出
    mouse_y : 鼠标单击位置的 y 坐标，初始化代码已给出
    鼠标左键单击地雷视为触雷
    '''
    mouse_x, mouse_y = get_mouse_pos() # 初始化

    ###############################
    # TODO : 根据提示，补全代码逻辑
    # return False # 这是错误的
    ###############################
    # 参考代码
    result = is_mine(mouse_x, mouse_y)
    ###############################

    return result                      # 返回结果 你应当把结果存放在 result 变量里

def is_win():
    '''
    判断是否胜利，胜利则返回 True，否则返回 False
    胜利条件是点开所有非地雷的格子，至于地雷格子是否插旗不重要
    get_mine_num() 返回地雷数量
    get_pressed_num() 返回已经单击过的点的数量
    w, h 分别表示地图的宽和高，已经在代码中初始化
    这次需要你自己写返回语句，形式是 return 返回值
    '''

    w, h = get_width_and_height()
    ###############################
    # TODO : 根据提示，用 if 语句补全代码逻辑
    # return False # 这是错误的
    ###############################
    # 参考代码
    mine_num = get_mine_num()
    pressed_num = get_pressed_num()
    return pressed_num == (w * h - mine_num)
    ###############################
    

def calc_mine_num(x, y):
    '''
    计算坐标 (x,y) 周围的地雷数目并返回，坐标范围是 0 <= x < w, 0 <= y < h
    程序会在生成地图后调用这个函数进行初始化
    w, h 分别表示地图的宽和高，已经在代码中初始化
    提示：使用 is_mine 函数，注意不要让下标越界
    注意：不要在这里使用下一题的 get_mine_num_around 函数，因为 get_mine_num_around 就是通过 calc_mine_num 计算的
    '''
    w, h = get_width_and_height()

    ###############################
    # TODO : 根据提示，补全代码逻辑
    # return 1 # 默认返回 1，这是错误的
    ###############################
    # 参考代码
    sum = 0
    if x > 0 and y > 0:
        sum += is_mine(x - 1, y - 1)   # 左上
    if x > 0:
        sum += is_mine(x - 1, y)       # 左
    if x > 0 and y < h - 1:
        sum += is_mine(x - 1, y + 1)   # 左下
    if y > 0:
        sum += is_mine(x, y - 1)       # 上
    if y < h - 1:
        sum += is_mine(x, y + 1)       # 下
    if x < w - 1 and y > 0:
        sum += is_mine(x + 1, y - 1)   # 右上
    if x < w - 1:
        sum += is_mine(x + 1, y)       # 右
    if x < w - 1 and y < h - 1:
        sum += is_mine(x + 1, y + 1)   # 右下
    return sum
    ###############################
    # 或者可以用如下的循环简化：
    # sum = 0
    # for next_x in range(max(x - 1, 0), min(x + 1, w - 1) + 1):      # 注意区间是左闭右开的
    #     for next_y in range(max(y - 1, 0), min(y + 1, h - 1) + 1):
    #         sum += is_mine(next_x, next_y)
    # sum -= is_mine(x, y) # 多加了自身，需要减去
    # return sum
        
# 如果你完成了上面的内容，那么扫雷小程序已经可以正常运行。
# 下面是一些扩展，可以极大地提升游戏体验，但是需要的知识可能超出了第一堂课的内容。

def zero_expand(x, y):
    '''
    这个函数的功能是检查坐标 (x,y) 周围的地雷数是否为 0，如果是，则将周围的8个格子全部点开
    如果对周围的格子再次调用此函数，则可以达到一次点开一大片的效果（可以提前了解一下递归的知识）
    注意避免两个相邻格子反复互相调用函数导致程序无法中止

    get_mine_num_around(x, y) 函数返回 (x,y) 周围的地雷数（或者你也可以使用 calc_mine_num）
    is_pressed(x,y) 返回布尔值，表示 (x,y) 是否被单击或模拟单击过
    expand(x,y) 模拟左键单击 (x,y)
    '''
    w, h = get_width_and_height()

    ###############################
    # TODO : 根据提示，补全代码逻辑
    # pass
    ###############################
    # 参考代码
    if get_mine_num_around(x, y) != 0:  # 判断当前节点的数值是否为 0
        return
    if x > 0 and y > 0 and not is_pressed(x - 1, y - 1): # 一定要用 is_pressed 避免重复调用
        expand(x - 1, y - 1)
        zero_expand(x - 1, y - 1)   # 左上
    if x > 0 and not is_pressed(x - 1, y):
        expand(x - 1, y)
        zero_expand(x - 1, y)       # 左
    if x > 0 and y < h - 1 and not is_pressed(x - 1, y + 1):
        expand(x - 1, y + 1)
        zero_expand(x - 1, y + 1)   # 左下
    if y > 0 and not is_pressed(x, y - 1):
        expand(x, y - 1)
        zero_expand(x, y - 1)       # 上
    if y < h - 1 and not is_pressed(x, y + 1):
        expand(x, y + 1)
        zero_expand(x, y + 1)       # 下
    if x < w - 1 and y > 0 and not is_pressed(x + 1, y - 1):
        expand(x + 1, y - 1)
        zero_expand(x + 1, y - 1)   # 右上
    if x < w - 1 and not is_pressed(x + 1, y):
        expand(x + 1, y)
        zero_expand(x + 1, y)       # 右
    if x < w - 1 and y < h - 1 and not is_pressed(x + 1, y + 1):
        expand(x + 1, y + 1)
        zero_expand(x + 1, y + 1)   # 右下
    ###############################
    # 这里提供另一种循环简化的方法：
    # if get_mine_num_around(x, y) != 0:  # 判断当前节点的数值是否为 0
    #     return
    # dx = [0, 1, 0, -1, -1, 1, -1, 1] # x坐标的变化量
    # dy = [-1, 0, 1, 0, -1, -1, 1, 1] # y坐标的变化量
    # for i in range(len(dx)):
    #     next_x = x + dx[i] # 求出下一个坐标
    #     next_y = y + dy[i]
    #     if next_x >= 0 and next_x < w and next_y >= 0 and next_y < h \
    #             and not is_pressed(next_x, next_y):
    #         expand(next_x, next_y)
    #         zero_expand(next_x, next_y)