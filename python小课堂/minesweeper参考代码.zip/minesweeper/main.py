# 不要修改此文件（除第 8 行）
import pygame
import game
import tools
import check

# 三个参数分别表示地图的宽、高和地雷数，可以手动调整
minesweeper = game.game(25, 15, 50)
tools.tools_init(minesweeper)
check.check_init(minesweeper)

while True:
   minesweeper.update()
   check.check()
   minesweeper.draw()