# 不要修改此文件
import pygame
import gui
import sys
import random

class game:
    def __init__(self, w, h, num_mine) -> None:
        '''
        To init the minesweeper game.
        param:
            w: the weight of the game board.
            h: the height of the game board.
            num_mine: the number of the mines.
        '''
        self.overflag = 0                       # the flag of game over
        self.col_wid = 150
        self.w = self.col_wid + w * 20          # game window weight
        self.h = max(h * 20, 100)                # game window height
        self.wn = w                             # the weight of the game board
        self.hn = h                             # the height of the game board
        self.num_mine = num_mine                # 显示的地雷数(地雷数减插旗数)
        self.real_num_mine = num_mine           # 真正的地雷数
        self.num_flag = 0                       # the number of the flags
        self.num_mine_with_flag = 0             # the number of the mines with flags
        self.col_list = {"normal":(205, 223, 175),"normal_fr":(240, 161, 110),\
                         "active":(255, 251, 172),"active_fr":(255, 212, 149),\
                         "pressed":(180, 122, 108),"pressed_fr":(125, 90, 80),\
                         "number1":(26, 188, 156),"number2":(41, 128, 185),"number3":(155, 89, 182),\
                         "number4":(241, 196, 15),"number5":(221, 66, 70),"number6":(230, 126, 34),\
                         "number7":(189, 195, 199),"number8":(175, 6, 6),"number9":(0,0,250)}   # mine color list.
        
        self.mine_list = []                     # mine button list

        # 长度为 w*h 的列表，按行优先存放，表示每个坐标是否存在地雷
        self.is_mine = [False] * w * h
        mines = random.sample(range(w * h), num_mine)
        for i in mines:
            self.is_mine[i] = True
        # print(self.is_mine)
        self.mousepos = None                    # 上一次鼠标左键点击的位置
        
        self.mouseflag = 0
        
        pygame.init()
        self.screen = pygame.display.set_mode((self.w, self.h))
        pygame.display.set_caption('Minesweeper')
        
        for j in range(self.hn):
            for i in range(self.wn):
                self.mine_list.append(gui.button(self.screen, self.col_list, (20, 20), (self.col_wid + i * 20, j * 20)))
        
        self.ABfont=pygame.font.SysFont('Arial Black', 24)
        
    
    def update(self):
        '''
        update the game.
        '''
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.mouseflag = event.button
            elif event.type == pygame.MOUSEBUTTONUP:
                self.mouseflag = 0
        
        if self.overflag != 0:
            return
        
        # 记录上一次单击的位置，以供触雷判定
        if self.mouseflag == 1:
            mouse_x_origin, mouse_y_origin = pygame.mouse.get_pos()
            mouse_x = (mouse_x_origin - self.col_wid) // 20
            mouse_y = mouse_y_origin // 20
            if mouse_x >= 0 and mouse_x < self.wn and mouse_y >= 0 and mouse_y < self.hn \
                    and self.mine_list[mouse_y * self.wn + mouse_x].state2 != 'flag':
                self.mousepos = (mouse_x_origin, mouse_y_origin)

        
        cnt = 0
        for bu in self.mine_list:
            bu.update(self.mouseflag)
            if bu.ispress(True):
                if bu.state2 == 'none':
                    if not self.is_mine[cnt]:
                        bu.state2 = 'empty'
                    else:
                        bu.state2 = 'mine'
                elif bu.state2 == 'flag':
                    bu.state2 = 'none'
                    self.num_flag -= 1
                    self.num_mine += 1
                    self.num_mine_with_flag -= self.is_mine[cnt]
            if bu.ispress(False):
                if bu.state2 == 'none':
                    bu.state2 = 'flag'
                    self.num_flag += 1
                    self.num_mine -= 1
                    self.num_mine_with_flag += self.is_mine[cnt]
                elif bu.state2 == 'flag':
                    bu.state2 = 'none'
                    self.num_flag -= 1
                    self.num_mine += 1
                    self.num_mine_with_flag -= self.is_mine[cnt]
            cnt += 1
    
    def draw(self):
        '''
        draw the game.
        '''
        pygame.draw.rect(self.screen, (166,187,141),(0,0,self.w,self.h))
        pygame.draw.rect(self.screen, (166,187,141),(self.col_wid, 0, self.w-self.col_wid, self.h))
        for bu in self.mine_list:
            bu.draw()
        
        pygame.draw.rect(self.screen, (60,98,85),(5,5,self.col_wid-10,60),border_radius=5)
        minetext = self.ABfont.render("Mine", 1, (166,187,141))
        mnumtext = self.ABfont.render(str(self.num_mine), 1, (234,231,177))
        self.screen.blit(minetext, (10, 5, 100, 100))
        self.screen.blit(mnumtext, (10, 30, 100, 100))
        if self.overflag == 1:
            wintext = self.ABfont.render("You Win!", 1, (6, 82, 221))
            self.screen.blit(wintext, (10, 65, 100, 100))
        elif self.overflag == -1:
            losetext = self.ABfont.render("You Lose!", 1, (192, 57, 43))
            self.screen.blit(losetext, (10, 65, 100, 100))
        pygame.display.flip()
        
    def flip_mine(self):
        for i in range(len(self.is_mine)):
            if self.is_mine[i]:
                self.mine_list[i].state2 = 'mine'
