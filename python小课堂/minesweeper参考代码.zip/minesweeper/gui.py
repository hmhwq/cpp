# 不要修改此文件
import pygame
import source
from copy import deepcopy

class button:
    def __init__(self, surface, col_list, size, pos) -> None:
        '''
        To init a mine button.
        param:
            surface: the surface which button is on.
            col_list: the color config of the button.
            size: (weight, height), the size of the button.
            pos: (x, y), the position of the button.
        '''
        self.surface = surface
        self.size = size
        self.pos = pos
        self.state1 = 'normal'
        self.state2 = 'none'
        self.col_list = col_list
        self.flagimg = pygame.image.load(deepcopy(source.flagimg), 'flie').convert_alpha()
        self.mineimg = pygame.image.load(deepcopy(source.mineimg), 'flie').convert_alpha()
        self.iconrect = (pos[0]+1, pos[1]+1, 18, 18)
        
        self.ABfont=pygame.font.SysFont('Arial Black', 18)
        self.num_mine = 0
        self.numrect = (pos[0]+4, pos[1]-3, 18, 18)
        
        
        self.isable = True
        self.press = 0
        pass
    
    def update(self, mouseflag):
        '''
        update function of the button.
        param:
            mouseflag: the state of mouse.(get by pygame).
        '''
        self.lasts=self.state1
        x, y = pygame.mouse.get_pos()
        if self.pos[0]<x<self.pos[0]+self.size[0] and self.pos[1]<y<self.pos[1]+self.size[1]:
            if self.isable == True:
                if mouseflag == 1 or mouseflag == 3:
                    self.state1 = 'pressed'
                    self.press = mouseflag
                else:
                    self.state1 = 'active'
        else:
            if self.isable == True:
                self.state1 ='normal'
    
    def simulate_click(self):
        '''
        在 logic.zero_expand 函数中使用，模拟左键单击按钮
        需要保证调用此方法的对象不是地雷格
        '''
        self.state1 = 'pressed'
        self.press = 1
    
    def draw(self):
        '''
        draw the button.
        '''
        pygame.draw.rect(self.surface, self.col_list[self.state1+'_fr'], (self.pos[0],self.pos[1],self.size[0],self.size[1]))
        if self.state2 == 'none':
            pygame.draw.rect(self.surface, self.col_list[self.state1], (self.pos[0]+1,self.pos[1]+1,self.size[0]-2,self.size[1]-2))
        elif self.state2 == 'mine':
            pygame.draw.rect(self.surface, self.col_list['pressed'], (self.pos[0]+1,self.pos[1]+1,self.size[0]-2,self.size[1]-2))
            self.surface.blit(self.mineimg, self.iconrect)
        elif self.state2 == 'flag':
            pygame.draw.rect(self.surface, self.col_list[self.state1], (self.pos[0]+1,self.pos[1]+1,self.size[0]-2,self.size[1]-2))
            self.surface.blit(self.flagimg, self.iconrect)
        elif self.state2 == 'empty': 
            pygame.draw.rect(self.surface, self.col_list['pressed'], (self.pos[0]+1,self.pos[1]+1,self.size[0]-2,self.size[1]-2))
            if self.num_mine > 0:
                ptext = self.ABfont.render(str(self.num_mine), 1, self.col_list['number' + str(self.num_mine)])
                self.surface.blit(ptext, self.numrect)
                
    def set_num(self, num):
        '''
        set the number will be display.
        '''
        self.num_mine = num
        
    def ispress(self, isleft):
        '''
        To judge is the button pressed.
        param:
            isleft: True - to judge Left-click. False - to judge Right-click.
        return:
            True - pressed.
            False - not pressed.
        '''
        temp = 3
        if isleft:
            temp = 1
        if (self.state1 == 'normal' or self.state1 == 'active') and self.press == temp:
            self.press = 0
            return True
        return False
