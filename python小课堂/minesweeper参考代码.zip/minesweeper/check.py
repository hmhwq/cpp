# 不要修改此文件
import logic
import game
import sys
import tools
import pandas as pd

def check_init(game_sample):
    '''
    用于在文件之间共享 minesweeper 变量
    '''
    global minesweeper
    minesweeper = game_sample
    
    # 初始化周围地雷的数目
    w = minesweeper.wn
    h = minesweeper.hn
    for y in range(h):
        for x in range(w):
            minesweeper.mine_list[y * w + x].set_num(logic.calc_mine_num(x, y))
    # 输出调试信息
    if logic.debug:
        print("每个格子的状态（1 表示有地雷）：")
        mine_data = []
        for y in range(h):
            row = []
            for x in range(w):
                row.append(int(minesweeper.is_mine[y * w + x]))
            mine_data.append(row)
        print(pd.DataFrame(mine_data))
        print("每个格子周围的地雷数：")
        map_data = []
        for y in range(h):
            row = []
            for x in range(w):
                row.append(minesweeper.mine_list[y * w + x].num_mine)
            map_data.append(row)
        print(pd.DataFrame(map_data))

def check():
    if minesweeper.overflag != 0 or minesweeper.mousepos == None:
        return
    elif logic.is_game_over():                     # 触雷判定
        print("\033[0;31;40mGame Over!\033[0m")
        minesweeper.overflag = -1
        minesweeper.flip_mine()
        #sys.exit()
    elif logic.is_win():                           # 胜利判定
        print("\033[0;32;40mYou Win!\033[0m")
        minesweeper.overflag = 1
        #sys.exit()
    else:  
        logic.zero_expand(*tools.get_mouse_pos())  # 零扩展快速开图