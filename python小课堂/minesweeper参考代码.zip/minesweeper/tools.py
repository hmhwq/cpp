# 不要修改此文件
# 一些代码逻辑部分需要用到的函数
import game
import pygame

def tools_init(game_sample):
    '''
    用于在文件之间共享 minesweeper 变量
    '''
    global minesweeper
    minesweeper= game_sample

def is_mine(x, y):
    '''
    判断 (x,y) 坐标处是否为地雷
    0 <= x < w
    0 <= y < h
    '''
    w = minesweeper.wn
    h = minesweeper.hn
    if x < 0 or x >= w or y < 0 or y >= h:
        print("\033[0;31;40mis_mine : 坐标越界\033[0m")
        raise Exception("Invalid coordinate")
    return minesweeper.is_mine[y * w + x]

def get_mouse_pos():
    '''
    获取鼠标指向的格子的坐标
    注意：这段代码默认格子的长宽均为 20，请不要随意更改
    '''
    x, y = minesweeper.mousepos
    return ((x - minesweeper.col_wid) // 20, y // 20)

def get_width_and_height():
    return (minesweeper.wn, minesweeper.hn)

def get_mine_num():
    return minesweeper.real_num_mine

def get_flag_num():
    return minesweeper.num_flag

def get_mine_with_flag_num():
    return minesweeper.num_mine_with_flag

def get_mine_num_around(x, y):
    '''
    返回坐标 (x,y) 周围的地雷数
    '''
    w = minesweeper.wn
    h = minesweeper.hn
    if x < 0 or x >= w or y < 0 or y >= h:
        print("\033[0;31;40mget_mine_num_around : 坐标越界\033[0m")
        raise Exception("Invalid coordinate")
    return minesweeper.mine_list[y * w + x].num_mine

def is_pressed(x, y):
    '''
    返回坐标 (x,y) 是否被单击过
    '''
    w = minesweeper.wn
    h = minesweeper.hn
    if x < 0 or x >= w or y < 0 or y >= h:
        print("\033[0;31;40mis_pressed : 坐标越界\033[0m")
        raise Exception("Invalid coordinate")
    return minesweeper.mine_list[y * w + x].state2 == 'empty' \
        or minesweeper.mine_list[y * w + x].state1 == 'pressed'

def get_pressed_num():
    '''
    返回已经点开的格子的数量
    '''
    num = 0
    for bu in minesweeper.mine_list:
        if bu.state2 == 'empty':
            num += 1
    return num

def expand(x, y):
    '''
    模拟左键单击 (x,y)
    '''
    w = minesweeper.wn
    h = minesweeper.hn
    if x < 0 or x >= w or y < 0 or y >= h:
        print("\033[0;31;40mexpand : 坐标越界\033[0m")
        raise Exception("Invalid coordinate")
    if minesweeper.is_mine[y * w + x]:
        print("\033[0;31;40mexpand : 模拟点击了地雷格\033[0m")
        raise Exception("Invalid coordinate")
    minesweeper.mine_list[y * w + x].simulate_click()